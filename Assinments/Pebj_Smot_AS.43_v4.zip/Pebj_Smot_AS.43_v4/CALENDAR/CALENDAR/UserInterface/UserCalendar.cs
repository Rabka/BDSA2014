﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CALENDAR.UserInterface
{
    public partial class UserCalendar : Form
    {
        public UserCalendar()
        {
            InitializeComponent();
        }
        public void LogOff()
        {
            throw new NotImplementedException();
        }
        public void GoBackToUserAccounts()
        {
            throw new NotImplementedException();
        }
        public void GoToEventPage()
        {
            throw new NotImplementedException();
        }
        public void UpdateEventAtEventPage()
        {
            throw new NotImplementedException();
        }
    }
}
