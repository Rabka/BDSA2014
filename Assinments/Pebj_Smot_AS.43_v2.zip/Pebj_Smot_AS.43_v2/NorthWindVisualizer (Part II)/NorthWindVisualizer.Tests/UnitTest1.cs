﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace NorthWindVisualizer.tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
