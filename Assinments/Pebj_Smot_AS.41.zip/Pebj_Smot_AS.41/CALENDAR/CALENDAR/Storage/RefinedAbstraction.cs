﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CALENDAR.Storage
{
    class RefinedAbstraction : Abstraction
    {
        public RefinedAbstraction(DBTypeImplementor imp) : base(imp)
        {
        }
    }
}
