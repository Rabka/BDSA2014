﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CALENDAR.GoogleCalendarAdapter
{
    /**
     * This class reflects the event structure of an event from GoogleRestAPILegacy
     **/
    class GoogleRestAPIEvent
    {
    }
}
