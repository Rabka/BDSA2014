﻿// Default code generation is disabled for model 'C:\Users\stin7054\Documents\GitHub\BDSA2014\BDSA2014_VSC#\Assignment40_PartIII\Assignment40_PartIII\Model\NorthWindDataModel.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.