﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CALENDAR.AccountManagement;
using CALENDAR.EventManagement;
namespace CALENDAR
{
    public partial class Form1 : Form
    {
        LoginPage loginPage = null;
        AccountPage accountPage = null;
        CreateAccountPage createAccountPage = null;
        CalendarPage calendarPage = null;
        EventPage eventPage = null;
        public Form1()
        {
            loginPage = new LoginPage();
            accountPage = new AccountPage();
            createAccountPage = new CreateAccountPage();
            calendarPage = new CalendarPage();
            eventPage = new EventPage();
            InitializeComponent();
        }
    }
}
