﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CALENDAR.UserInterface
{
    public partial class AccountPage : Form
    {
        public AccountPage()
        {
            InitializeComponent();
        }
        public void updateInfo(string password, string email)
        {
            throw new NotImplementedException();
        }
        public void deleteMyAccount()
        {
            throw new NotImplementedException();
        }
    }
}
