﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CALENDAR.UserInterface
{
    public partial class CreateAccountPage : Form
    {
        public CreateAccountPage()
        {
            InitializeComponent();
        }
        public bool TryCreateAccount(string username,string password, string email)
        {
            throw new NotImplementedException();
        }
        public void GoToLogin()
        {
            throw new NotImplementedException();
        }
    }
}
