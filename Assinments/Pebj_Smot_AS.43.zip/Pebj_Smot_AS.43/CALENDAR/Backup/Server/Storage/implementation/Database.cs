﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace Server.Database
{
    public static class Database
    {
        //Depending on the type of database, this could be handling an SQL database or a local CSV file.
    }
}