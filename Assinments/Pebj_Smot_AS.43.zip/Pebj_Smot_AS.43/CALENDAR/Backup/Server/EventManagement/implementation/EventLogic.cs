﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace Server.EventManagement
{
    public static class EventLogic
    {
      
        /// <summary>
        /// Gets an event with a specified ID.
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public static Entities.Implementation.Event getEventByID(string ID)
        {
            return null;
        }
    }
}