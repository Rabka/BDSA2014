﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CALENDAR.UserInterface
{
    public partial class LoginPage : Form
    {
        public LoginPage()
        {
            InitializeComponent();
        }
       void GoToCreateAccount()
        {
            throw new NotImplementedException();
       }
       bool LoginAttempt(){
           throw new NotImplementedException();
       }
       void GoToCalendarPage()
       {
           throw new NotImplementedException();
       }
    }
}
