﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment35_HelloWorld
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            // Output text to the screen.
            Console.WriteLine("Hello World");
            Console.ReadKey();
        }
    }
}
