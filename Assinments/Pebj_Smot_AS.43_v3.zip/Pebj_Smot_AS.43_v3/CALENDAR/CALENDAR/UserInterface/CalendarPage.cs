﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CALENDAR.UserInterface
{
    public partial class CalendarPage : Form
    {
        public CalendarPage()
        {
            InitializeComponent();
        }
        public void GoToAccountPage()
        {
            throw new NotImplementedException();
        }
        public void LogOff()
        {
            throw new NotImplementedException();
        }
        public void GoToEventPage()
        {
            throw new NotImplementedException();
        }
        public void UpdateEventAtEventPage()
        {
            throw new NotImplementedException();
        }
    }
}
